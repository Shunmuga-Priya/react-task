import React from 'react';
import User from './User';

class  Hint extends React.Component{
    render(){
        return(
            <div><br /><br /><br />{this.props.hname}</div>
        )
    }
   
    }

export default Hint; 