import React from 'react';
import uuid from 'uuid';

class FormTesting extends React.Component{
    state = {
        id:null,
        email:"",
        password:"",
        group:[],
        // check:"",
    }
    submitData = (e) => {
        console.log("e-value",e);
        e.preventDefault();
        var email = e.target.elements.email.value
        var password = e.target.elements.password.value
        var id = uuid();
        this.setState({
            
            id,
           email,
           password
        })

        this.state.group.push({id,email,password})
        
        e.target.elements.email.value="";
        e.target.elements.password.value="";
    }
   
    render(){
        console.log(this.state.group)
        return(
            <>
                <form onSubmit={this.submitData}>
                    <input type="text" name="email" /><br></br>
                    <input type="text" name="password" />
                    <button type="submit">Submit</button>
                </form>
               <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">Email</th>
                        <th scope="col">Name</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       
                        {
                            this.state.group.map((val)=>{
                                return(
                                    <tr>
                                        <td>{val.email}</td>
                                        <td>{val.password}</td>
                                        <button type = "reset"className="btn btn-primary btn-sm">Edit</button>
                                        <button className="btn btn-danger btn-sm">Delete</button>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>

            </>
        )
       
    }
}

export default FormTesting;