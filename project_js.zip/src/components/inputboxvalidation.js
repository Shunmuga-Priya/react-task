import React from "react";

class Inputbox extends React.Component{
    render(){
    return(
        <div>
        <input type="text" class="form-control" 
        id="validationCustom01" 
        placeholder="First name" 
        value="Mark" required></input>
        </div>

    )
    }
}

export default Inputbox;